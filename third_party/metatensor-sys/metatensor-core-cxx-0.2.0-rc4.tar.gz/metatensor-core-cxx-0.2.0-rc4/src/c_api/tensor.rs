use std::os::raw::c_char;
use std::sync::Arc;
use std::ffi::CStr;
use std::ffi::CString;
use crate::utils::ConstCString;
use std::collections::BTreeSet;

use dlpk::sys::{DLDataType, DLDataTypeCode, DLDevice};

use crate::data::mts_array_t;
use crate::{TensorMap, TensorBlock, Error};

use super::labels::mts_labels_t;
use super::blocks::mts_block_t;
use super::status::{mts_status_t, catch_unwind};

/// Opaque type representing a `TensorMap`.
#[allow(non_camel_case_types)]
pub struct mts_tensormap_t(TensorMap);

impl mts_tensormap_t {
    /// Create a raw pointer to `mts_tensormap_t` using a rust Box
    pub fn into_boxed_raw(tensor: TensorMap) -> *mut mts_tensormap_t {
        let boxed = Box::new(mts_tensormap_t(tensor));
        return Box::into_raw(boxed);
    }

    /// Take a raw pointer created by `mts_tensormap_t::into_boxed_raw` and
    /// extract the TensorMap. The pointer is consumed by this function and no
    /// longer valid.
    pub unsafe fn from_boxed_raw(tensor: *mut mts_tensormap_t) -> TensorMap {
        return Box::from_raw(tensor).0;
    }
}

impl std::ops::Deref for mts_tensormap_t {
    type Target = TensorMap;
    fn deref(&self) -> &Self::Target {
        &self.0
    }
}

impl std::ops::DerefMut for mts_tensormap_t {
    fn deref_mut(&mut self) -> &mut Self::Target {
        &mut self.0
    }
}


/// Create a new `mts_tensormap_t` with the given `keys` and `blocks`.
/// `blocks_count` must be set to the number of entries in the blocks array.
///
/// The new tensor map takes ownership of the blocks and keys, which should
/// not be released separately.
///
/// The memory allocated by this function and the blocks should be released
/// using `mts_tensormap_free`.
///
/// @param keys pointer to labels containing the keys associated with each
///             block. The new tensor map will increase the reference count
///             of these labels
/// @param blocks pointer to the first element of an array of blocks. The
///               tensor map takes ownership of the blocks.
/// @param blocks_count number of elements in the `blocks` array
///
/// @returns A pointer to the newly allocated tensor map, or a `NULL` pointer in
///          case of error. In case of error, you can use `mts_last_error()`
///          to get the error message.
#[no_mangle]
pub unsafe extern "C" fn mts_tensormap(
    keys: *const mts_labels_t,
    blocks: *mut *mut mts_block_t,
    blocks_count: usize,
) -> *mut mts_tensormap_t {
    let mut result = std::ptr::null_mut();
    let unwind_wrapper = std::panic::AssertUnwindSafe(&mut result);

    let status = catch_unwind(move || {
        check_pointers_non_null!(keys);

        let mut blocks_vec = Vec::new();
        if blocks_count != 0 {
            check_pointers_non_null!(blocks);

            let blocks_slice = std::slice::from_raw_parts_mut(blocks, blocks_count);
            // check for uniqueness of the pointers: we don't want to move out
            // the same value twice
            if blocks_slice.iter().collect::<BTreeSet<_>>().len() != blocks_slice.len() {
                return Err(Error::InvalidParameter(
                    "got the same block more than once when constructing a tensor map".into()
                ));
            }

            for block_ptr in blocks_slice {
                // move out of the blocks pointers
                let block = Box::from_raw(*block_ptr).into_block();
                *block_ptr = std::ptr::null_mut();
                blocks_vec.push(block);
            }
        }

        let keys = mts_labels_t::arc_clone(keys);
        let tensor = TensorMap::new(keys, blocks_vec)?;

        // force the closure to capture the full unwind_wrapper, not just
        // unwind_wrapper.0
        let _ = &unwind_wrapper;
        *unwind_wrapper.0 = mts_tensormap_t::into_boxed_raw(tensor);
        Ok(())
    });

    if !status.is_success() {
        return std::ptr::null_mut();
    }

    return result;
}


/// Free the memory associated with a `tensor` previously created with
/// `mts_tensormap`.
///
/// If `tensor` is `NULL`, this function does nothing.
///
/// @param tensor pointer to an existing tensor map, or `NULL`
///
/// @returns The status code of this operation. If the status is not
///          `MTS_SUCCESS`, you can use `mts_last_error()` to get the full
///          error message.
#[no_mangle]
pub unsafe extern "C" fn mts_tensormap_free(tensor: *mut mts_tensormap_t) -> mts_status_t {
    catch_unwind(|| {
        if !tensor.is_null() {
            std::mem::drop(mts_tensormap_t::from_boxed_raw(tensor));
        }

        Ok(())
    })
}

/// Make a copy of an `mts_tensormap_t`.
///
/// The memory allocated by this function and the blocks should be released
/// using `mts_tensormap_free`.
///
/// @param tensor existing tensor to copy
///
/// @returns A pointer to the newly allocated tensor, or a `NULL` pointer in
///          case of error. In case of error, you can use `mts_last_error()`
///          to get the error message.
#[no_mangle]
pub unsafe extern "C" fn mts_tensormap_copy(
    tensor: *const mts_tensormap_t,
) -> *mut mts_tensormap_t {
    let mut result = std::ptr::null_mut();
    let unwind_wrapper = std::panic::AssertUnwindSafe(&mut result);
    let status = catch_unwind(move || {
        check_pointers_non_null!(tensor);
        let new_tensor = (*tensor).try_clone()?;
        let boxed = Box::new(mts_tensormap_t(new_tensor));

        // force the closure to capture the full unwind_wrapper, not just
        // unwind_wrapper.0
        let _ = &unwind_wrapper;
        *(unwind_wrapper.0) = Box::into_raw(boxed);
        Ok(())
    });

    if !status.is_success() {
        return std::ptr::null_mut();
    }

    return result;
}


/// Get the keys for the given `tensor` map.
///
/// This function allocates memory for the returned labels which must be
/// released with `mts_labels_free` when you don't need it anymore.
///
/// @param tensor pointer to an existing tensor map
///
/// @returns A pointer to the newly allocated labels containing the keys, or a
///          `NULL` pointer in case of error. In case of error, you can use
///          `mts_last_error()` to get the error message.
#[no_mangle]
pub unsafe extern "C" fn mts_tensormap_keys(
    tensor: *const mts_tensormap_t,
) -> *const mts_labels_t {
    let mut result = std::ptr::null();
    let unwind_wrapper = std::panic::AssertUnwindSafe(&mut result);

    let status = catch_unwind(move || {
        check_pointers_non_null!(tensor);

        let _ = &unwind_wrapper;
        *unwind_wrapper.0 = mts_labels_t::into_raw(Arc::clone((*tensor).keys()));
        Ok(())
    });

    if !status.is_success() {
        return std::ptr::null();
    }

    return result;
}


/// Get a pointer to the `index`-th block in this tensor map.
///
/// The block memory is still managed by the tensor map, this block should not
/// be freed. The block is invalidated when the tensor map is freed with
/// `mts_tensormap_free` or the set of keys is modified by calling one
/// of the `mts_tensormap_keys_to_XXX` function.
///
/// @param tensor pointer to an existing tensor map
/// @param block pointer to be filled with a block
/// @param index index of the block to get
///
/// @returns The status code of this operation. If the status is not
///          `MTS_SUCCESS`, you can use `mts_last_error()` to get the full
///          error message.
#[no_mangle]
pub unsafe extern "C" fn mts_tensormap_block_by_id(
    tensor: *mut mts_tensormap_t,
    block: *mut *mut mts_block_t,
    index: usize,
) -> mts_status_t {
    catch_unwind(|| {
        check_pointers_non_null!(tensor, block);

        let blocks = (*tensor).blocks_mut();
        match blocks.get_mut(index) {
            Some(b) => {
                (*block) = (b as *mut TensorBlock).cast();
            }
            None => {
                return Err(Error::InvalidParameter(format!(
                    "block index out of bounds: we have {} blocks but the index is {}",
                    blocks.len(), index
                )));
            }
        }

        Ok(())
    })
}


/// Merge blocks with the same value for selected keys dimensions along the
/// property axis.
///
/// The dimensions (names) of `keys_to_move` will be moved from the keys to
/// the property labels, and blocks with the same remaining keys dimensions
/// will be merged together along the property axis.
///
/// If `keys_to_move` does not contain any entries (`keys_to_move.count
/// == 0`), then the new property labels will contain entries corresponding
/// to the merged blocks only. For example, merging a block with key `a=0`
/// and properties `p=1, 2` with a block with key `a=2` and properties `p=1,
/// 3` will produce a block with properties `a, p = (0, 1), (0, 2), (2, 1),
/// (2, 3)`.
///
/// If `keys_to_move` contains entries, then the property labels must be the
/// same for all the merged blocks. In that case, the merged property labels
/// will contain each of the entries of `keys_to_move` and then the current
/// property labels. For example, using `a=2, 3` in `keys_to_move`, and
/// blocks with properties `p=1, 2` will result in `a, p = (2, 1), (2, 2),
/// (3, 1), (3, 2)`.
///
/// The new sample labels will contain all of the merged blocks sample
/// labels. The order of the samples is controlled by `sort_samples`. If
/// `sort_samples` is true, samples are re-ordered to keep them
/// lexicographically sorted. Otherwise they are kept in the order in which
/// they appear in the blocks.
///
/// The result is a new tensor map, which should be freed with `mts_tensormap_free`.
///
/// @param tensor pointer to an existing tensor map
/// @param keys_to_move description of the keys to move
/// @param fill_value an mts_array_t containing a single scalar of the same
///                   dtype as the data, used to fill missing entries when
///                   merging blocks. This function takes ownership of
///                  `fill_value`, and will free it when it's not needed anymore.
/// @param sort_samples whether to sort the samples lexicographically after
///                     merging blocks
///
/// @returns A pointer to the newly allocated tensor map, or a `NULL` pointer in
///          case of error. In case of error, you can use `mts_last_error()`
///          to get the error message.
#[no_mangle]
pub unsafe extern "C" fn mts_tensormap_keys_to_properties(
    tensor: *const mts_tensormap_t,
    keys_to_move: *const mts_labels_t,
    fill_value: mts_array_t,
    sort_samples: bool,
) -> *mut mts_tensormap_t {
    let mut result = std::ptr::null_mut();
    let unwind_wrapper = std::panic::AssertUnwindSafe(&mut result);

    let status = catch_unwind(move || {
        check_pointers_non_null!(tensor, keys_to_move);

        let keys_to_move = mts_labels_t::arc_clone(keys_to_move);

        let moved = (*tensor).keys_to_properties(&keys_to_move, &fill_value, sort_samples)?;

        std::mem::drop(fill_value);

        let _ = &unwind_wrapper;
        *unwind_wrapper.0 = mts_tensormap_t::into_boxed_raw(moved);
        Ok(())
    });

    if !status.is_success() {
        return std::ptr::null_mut();
    }

    return result;
}


/// Move the given dimensions from the component labels to the property labels
/// for each block in this tensor map.
///
/// `dimensions` must be an array of `dimensions_count` NULL-terminated strings,
/// encoded as UTF-8.
///
/// @param tensor pointer to an existing tensor map
/// @param dimensions names of the key dimensions to move to the properties
/// @param dimensions_count number of entries in the `dimensions` array
///
/// @returns The status code of this operation. If the status is not
///          `MTS_SUCCESS`, you can use `mts_last_error()` to get the full
///          error message.
#[no_mangle]
pub unsafe extern "C" fn mts_tensormap_components_to_properties(
    tensor: *const mts_tensormap_t,
    dimensions: *const *const c_char,
    dimensions_count: usize,
) -> *mut mts_tensormap_t {
    let mut result = std::ptr::null_mut();
    let unwind_wrapper = std::panic::AssertUnwindSafe(&mut result);

    let status = catch_unwind(move || {
        check_pointers_non_null!(tensor, dimensions);

        assert!(dimensions_count != 0);
        let mut rust_dimensions = Vec::new();
        for &dimension in std::slice::from_raw_parts(dimensions, dimensions_count) {
            check_pointers_non_null!(dimension);
            let dimension = CStr::from_ptr(dimension).to_str().expect("invalid utf8");
            rust_dimensions.push(dimension);
        }

        let moved = (*tensor).components_to_properties(&rust_dimensions)?;

        // force the closure to capture the full unwind_wrapper, not just
        // unwind_wrapper.0
        let _ = &unwind_wrapper;
        *unwind_wrapper.0 = mts_tensormap_t::into_boxed_raw(moved);

        Ok(())
    });

    if !status.is_success() {
        return std::ptr::null_mut();
    }

    return result;
}

/// Merge blocks with the same value for selected keys dimensions along the
/// samples axis.
///
/// The dimensions (names) of `keys_to_move` will be moved from the keys to
/// the sample labels, and blocks with the same remaining keys dimensions
/// will be merged together along the sample axis.
///
/// `keys_to_move` must be empty (`keys_to_move.count == 0`), and the new
/// sample labels will contain entries corresponding to the merged blocks'
/// keys.
///
/// The new sample labels will contain all of the merged blocks sample
/// labels. The order of the samples is controlled by `sort_samples`. If
/// `sort_samples` is true, samples are re-ordered to keep them
/// lexicographically sorted. Otherwise they are kept in the order in which
/// they appear in the blocks.
///
/// @param tensor pointer to an existing tensor map
/// @param keys_to_move description of the keys to move
/// @param fill_value an mts_array_t containing a single scalar of the same
///                   dtype as the data, used to fill missing entries when
///                   merging blocks. This function takes ownership of
///                  `fill_value`, and will free it when it's not needed anymore.
/// @param sort_samples whether to sort the samples lexicographically after
///                     merging blocks or not
///
/// @returns The status code of this operation. If the status is not
///          `MTS_SUCCESS`, you can use `mts_last_error()` to get the full
///          error message.
#[no_mangle]
pub unsafe extern "C" fn mts_tensormap_keys_to_samples(
    tensor: *const mts_tensormap_t,
    keys_to_move: *const mts_labels_t,
    fill_value: mts_array_t,
    sort_samples: bool,
) -> *mut mts_tensormap_t {
    let mut result = std::ptr::null_mut();
    let unwind_wrapper = std::panic::AssertUnwindSafe(&mut result);

    let status = catch_unwind(move || {
        check_pointers_non_null!(tensor, keys_to_move);

        let keys_to_move = mts_labels_t::arc_clone(keys_to_move);

        let moved = (*tensor).keys_to_samples(&keys_to_move, &fill_value, sort_samples)?;

        std::mem::drop(fill_value);

        let _ = &unwind_wrapper;
        *unwind_wrapper.0 = mts_tensormap_t::into_boxed_raw(moved);
        Ok(())
    });

    if !status.is_success() {
        return std::ptr::null_mut();
    }

    return result;
}

/// Set or update the info (i.e. global metadata) for `key` to `value` for this
/// tensor map.
///
/// @param tensor pointer to an existing tensor map
/// @param key string key of the entry we are trying to set
/// @param value content of the info field
///
/// @returns The status code of this operation. If the status is not
///          `MTS_SUCCESS`, you can use `mts_last_error()` to get the full
///          error message.
#[no_mangle]
pub unsafe extern "C" fn mts_tensormap_set_info(
    tensor: *mut mts_tensormap_t,
    key: *const c_char,
    value: *const c_char,
) -> mts_status_t {
    catch_unwind(|| {
        check_pointers_non_null!(tensor, key, value);

        let key = CStr::from_ptr(key).to_str()
            .map_err(|e| Error::InvalidParameter(format!("Invalid UTF-8 in key: {}", e)))?;

        let value = CString::new(CStr::from_ptr(value).to_bytes())
            .map_err(|e| Error::InvalidParameter(format!("Invalid C string in value: {}", e)))?;

        (*tensor).add_info(key, ConstCString::new(value));
        Ok(())
    })
}

/// Get the info (i.e. global metadata) `value` associated with `key` for this
/// tensor map.
///
/// @param tensor pointer to an existing tensor map
/// @param key string key of the entry we are trying to access
/// @param value will be set to content of the info field, or `NULL` if the key
///             does not exist.
///
/// @returns The status code of this operation. If the status is not
///          `MTS_SUCCESS`, you can use `mts_last_error()` to get the full
///          error message.
#[no_mangle]
pub unsafe extern "C" fn mts_tensormap_get_info(
    tensor: *const mts_tensormap_t,
    key: *const c_char,
    value: *mut *const c_char,
) -> mts_status_t {
    catch_unwind(|| {
        check_pointers_non_null!(tensor, key, value);

        let key_str = CStr::from_ptr(key).to_str()
            .map_err(|e| Error::InvalidParameter(format!("Invalid UTF-8 in key: {}", e)))?;

        if let Some(val) = (*tensor).get_info(key_str) {
            *value = val.as_c_str().as_ptr();
        } else {
            *value = std::ptr::null();
        }

        Ok(())
    })
}

/// Get the list of currently set info keys for this tensor map.
///
/// @param tensor pointer to an existing tensor map
/// @param keys will be set to point to an array of C strings
/// @param keys_count the number of entries in the `keys` array
///
/// @returns The status code of this operation. If the status is not
///          `MTS_SUCCESS`, you can use `mts_last_error()` to get the full
///          error message.
#[no_mangle]
pub unsafe extern "C" fn mts_tensormap_info_keys(
    tensor: *const mts_tensormap_t,
    keys: *mut *const *const c_char,
    keys_count: *mut usize,
) -> mts_status_t {
    catch_unwind(|| {
        check_pointers_non_null!(tensor, keys, keys_count);

        let list = (*tensor).info_keys_c();
        (*keys_count) = list.len();

        (*keys) = if list.is_empty() {
            std::ptr::null()
        } else {
            list.as_ptr().cast()
        };
        Ok(())
    })
}


/// Get the device of this tensor map.
///
/// For an empty tensor map, the device is set to CPU.
///
/// @param tensor pointer to an existing tensor map
/// @param device pointer to a `DLDevice` that will be set to the tensor's device
///
/// @returns The status code of this operation. If the status is not
///          `MTS_SUCCESS`, you can use `mts_last_error()` to get the full
///          error message.
#[no_mangle]
pub unsafe extern "C" fn mts_tensormap_device(
    tensor: *const mts_tensormap_t,
    device: *mut DLDevice,
) -> mts_status_t {
    catch_unwind(|| {
        check_pointers_non_null!(tensor, device);
        let tensor = &(*tensor);
        let blocks = tensor.blocks();
        if blocks.is_empty() {
            *device = DLDevice::cpu();
        } else {
            *device = blocks[0].values.device()?;
        }
        Ok(())
    })
}


/// Get the data type of this tensor map.
///
/// For an empty tensor map (no blocks), the dtype is set to float64.
///
/// @param tensor pointer to an existing tensor map
/// @param dtype pointer to a `DLDataType` that will be set to the tensor's dtype
///
/// @returns The status code of this operation. If the status is not
///          `MTS_SUCCESS`, you can use `mts_last_error()` to get the full
///          error message.
#[no_mangle]
pub unsafe extern "C" fn mts_tensormap_dtype(
    tensor: *const mts_tensormap_t,
    dtype: *mut DLDataType,
) -> mts_status_t {
    catch_unwind(|| {
        check_pointers_non_null!(tensor, dtype);
        let tensor = &(*tensor);
        let blocks = tensor.blocks();
        if blocks.is_empty() {
            *dtype = DLDataType { code: DLDataTypeCode::kDLFloat, bits: 64, lanes: 1 };
        } else {
            *dtype = blocks[0].values.dtype()?;
        }
        Ok(())
    })
}
