use std::sync::Arc;

use indexmap::IndexSet;

use crate::labels::Labels;
use crate::{Error, TensorBlock};

use crate::data::{mts_array_t, mts_data_movement_t};

use super::TensorMap;
use super::utils::{KeyAndBlock, remove_dimensions_from_keys, merge_samples, merge_gradient_samples};


impl TensorMap {
    /// Merge blocks with the same value for selected keys dimensions along the
    /// property axis.
    ///
    /// The dimensions (names) of `keys_to_move` will be moved from the keys to
    /// the property labels, and blocks with the same remaining keys dimensions
    /// will be merged together along the property axis.
    ///
    /// If `keys_to_move` does not contain any entries (`keys_to_move.count()
    /// == 0`), then the new property labels will contain entries corresponding
    /// to the merged blocks only. For example, merging a block with key `a=0`
    /// and properties `p=1, 2` with a block with key `a=2` and properties `p=1,
    /// 3` will produce a block with properties `a, p = (0, 1), (0, 2), (2, 1),
    /// (2, 3)`.
    ///
    /// If `keys_to_move` contains entries, then the property labels must be the
    /// same for all the merged blocks. In that case, the merged property labels
    /// will contain each of the entries of `keys_to_move` and then the current
    /// property labels. For example, using `a=2, 3` in `keys_to_move`, and
    /// blocks with properties `p=1, 2` will result in `a, p = (2, 1), (2, 2),
    /// (3, 1), (3, 2)`.
    ///
    /// The new sample labels will contain all of the merged blocks sample
    /// labels. The order of the samples is controlled by `sort_samples`. If
    /// `sort_samples` is true, samples are re-ordered to keep them
    /// lexicographically sorted. Otherwise they are kept in the order in which
    /// they appear in the blocks.
    pub fn keys_to_properties(&self, keys_to_move: &Labels, fill_value: &mts_array_t, sort_samples: bool) -> Result<TensorMap, Error> {
        if self.keys.is_empty() {
            return Err(Error::InvalidParameter(
                "there are no keys to move in an empty TensorMap".into()
            ));
        }

        let dimensions_to_move = keys_to_move.dimensions();
        let splitted_keys = remove_dimensions_from_keys(&self.keys, &dimensions_to_move)?;

        let keys_to_move = if keys_to_move.count() == 0 {
            None
        } else {
            Some(keys_to_move)
        };

        let mut new_blocks = Vec::new();
        if splitted_keys.new_keys.count() == 1 {
            // create a single block with everything
            let blocks_to_merge = self.keys.to_cpu().iter()
                .zip(&self.blocks)
                .map(|(key, block)| {
                    let mut moved_key = Vec::new();
                    for &i in &splitted_keys.dimensions_positions {
                        moved_key.push(key[i]);
                    }

                    KeyAndBlock {
                        key: moved_key,
                        block
                    }
                })
                .collect::<Vec<_>>();

            let block = merge_blocks_along_properties(
                &blocks_to_merge,
                keys_to_move,
                &dimensions_to_move,
                sort_samples,
                fill_value,
            )?;
            new_blocks.push(block);
        } else {
            assert!(splitted_keys.new_keys.count() > 1);
            let mut matching = vec![0; self.keys.count()];
            for entry in &splitted_keys.new_keys.to_cpu() {
                let selection = Labels::from_vec(
                    &splitted_keys.new_keys.dimensions(),
                    entry.to_vec(),
                ).expect("invalid labels");

                let n_matched = self.keys.select(&selection, &mut matching)?;

                let cpu_keys = self.keys.to_cpu();
                #[allow(clippy::cast_possible_truncation)]
                let blocks_to_merge = matching.iter()
                    .take(n_matched)
                    .map(|&i| {
                        let i = i as usize;
                        let block = &self.blocks[i];
                        let key = &cpu_keys[i];
                        let mut moved_key = Vec::new();
                        for &i in &splitted_keys.dimensions_positions {
                            moved_key.push(key[i]);
                        }

                        KeyAndBlock {
                            key: moved_key,
                            block
                        }
                    })
                    .collect::<Vec<_>>();

                let block = merge_blocks_along_properties(
                    &blocks_to_merge,
                    keys_to_move,
                    &dimensions_to_move,
                    sort_samples,
                    fill_value,
                )?;
                new_blocks.push(block);
            }
        }

        let mut tensor = TensorMap::new(Arc::new(splitted_keys.new_keys), new_blocks)?;
        for (k, v) in &self.info {
            tensor.add_info(k, v.clone());
        }

        return Ok(tensor);
    }
}

/// Merge the given `blocks` along the property axis.
#[allow(clippy::too_many_lines)]
fn merge_blocks_along_properties(
    blocks_to_merge: &[KeyAndBlock],
    keys_to_move: Option<&Labels>,
    extracted_names: &[&str],
    sort_samples: bool,
    fill_value: &mts_array_t,
) -> Result<TensorBlock, Error> {
    assert!(!blocks_to_merge.is_empty());

    let first_block = blocks_to_merge[0].block;
    for gradient in first_block.gradients().values() {
        if !gradient.gradients().is_empty() {
            return Err(Error::InvalidParameter(
                "gradient of gradients are not supported yet in keys_to_properties".into()
            ));
        }
    }

    let first_components_label = &first_block.components;
    let first_property_labels = &first_block.properties;
    for KeyAndBlock{block, ..} in blocks_to_merge {
        if &block.components != first_components_label {
            return Err(Error::InvalidParameter(
                "can not move keys to properties if the blocks have \
                different components labels, call components_to_properties first".into()
            ));
        }

        if keys_to_move.is_some() && &block.properties != first_property_labels {
            // TODO: this might be possible but also pretty slow. It would
            // requires to lookup the position of properties one by one in the
            // merged properties
            return Err(Error::InvalidParameter(
                "can not provide values for the keys to move to properties if \
                the blocks have different property labels".into()
            ));
        }
    }

    // collect and merge samples across the blocks
    let (merged_samples, samples_mappings) = merge_samples(
        blocks_to_merge,
        &first_block.samples.dimensions(),
        sort_samples,
    );

    let mut new_properties = IndexSet::new();
    if let Some(keys_to_move) = keys_to_move {
        // use the user-provided new values
        for new_property in &keys_to_move.to_cpu() {
            for KeyAndBlock{block, ..} in blocks_to_merge {
                for old_property in &block.properties.to_cpu() {
                    let mut property = new_property.to_vec();
                    property.extend_from_slice(old_property);
                    new_properties.insert(property);
                }
            }
        }
        assert_eq!(new_properties.len(), first_property_labels.count() * keys_to_move.count());
    } else {
        // collect properties from the blocks, augmenting them with the new
        // properties
        for KeyAndBlock{key, block} in blocks_to_merge {
            for old_property in &block.properties.to_cpu() {
                let mut property = key.clone();
                property.extend_from_slice(old_property);
                new_properties.insert(property);
            }
        }
    }

    let new_property_names = extracted_names.iter()
        .chain(first_block.properties.dimensions().iter())
        .copied()
        .collect::<Vec<_>>();

    let new_properties = unsafe {
        // SAFETY: the values come from a set, so they are already unique
        Arc::new(Labels::from_vec_unchecked_uniqueness(
            &new_property_names,
            new_properties.iter().flatten().copied().collect()
        ).expect("invalid labels"))
    };

    let new_components = first_block.components.to_vec();
    let new_properties_count = new_properties.count();

    // create a new array and move the data around
    let mut new_shape = first_block.values.shape()?.to_vec();
    new_shape[0] = merged_samples.count();
    let property_axis = new_shape.len() - 1;
    new_shape[property_axis] = new_properties_count;
    let mut new_data = first_block.values.create(&new_shape, fill_value)?;

    // compute the property range for each block, i.e. where we want to put
    // the corresponding data
    let mut property_ranges = Vec::new();
    for KeyAndBlock{key, block} in blocks_to_merge {
        if block.properties.is_empty() {
            // no properties, ignore this block
            property_ranges.push(None);
            continue;
        }

        let mut first = key.clone();
        first.extend_from_slice(&block.properties.to_cpu()[0]);

        // we can lookup only the `first` new property here, since the new
        // properties match exactly the old ones, just with an added "channel"
        // of the moved key.

        // start can be None is the user requested a set of values which do not
        // include the key for the current block
        let start = new_properties.position(&first);
        let size = block.properties.count();
        if let Some(start) = start {
            property_ranges.push(Some(start..(start + size)));
        } else {
            property_ranges.push(None);
        }
    }

    debug_assert_eq!(blocks_to_merge.len(), samples_mappings.len());
    debug_assert_eq!(blocks_to_merge.len(), property_ranges.len());
    // for each block, gather the data to be moved & send it in one go
    for ((KeyAndBlock{block, ..}, samples_mapping), property_range) in blocks_to_merge.iter().zip(&samples_mappings).zip(&property_ranges) {
        if let Some(property_range) = property_range {
            let mut movements = Vec::new();
            for (sample_i, &new_sample_i) in samples_mapping.iter().enumerate() {
                movements.push(mts_data_movement_t {
                    sample_in: sample_i,
                    sample_out: new_sample_i,
                    properties_start_in: 0,
                    properties_start_out: property_range.start,
                    properties_length: property_range.len(),
                });
            }

            new_data.move_data(&block.values, &movements)?;
        }
    }

    let mut new_block = TensorBlock::new(
        new_data,
        merged_samples,
        new_components,
        new_properties
    ).expect("constructed an invalid block");

    // now collect & merge the different gradients
    for (parameter, first_gradient) in first_block.gradients() {
        let new_gradient_samples = merge_gradient_samples(
            blocks_to_merge, parameter, &samples_mappings
        );

        let mut new_shape = first_gradient.values.shape()?.to_vec();
        new_shape[0] = new_gradient_samples.count();
        let property_axis = new_shape.len() - 1;
        new_shape[property_axis] = new_properties_count;

        let mut new_gradient = first_block.values.create(&new_shape, fill_value)?;
        let new_components = first_gradient.components.to_vec();

        for ((KeyAndBlock{block, ..}, samples_mapping), property_range) in blocks_to_merge.iter().zip(&samples_mappings).zip(&property_ranges) {
            if property_range.is_none() {
                continue;
            }

            let property_range = property_range.as_ref().unwrap();
            let gradient = block.gradient(parameter).expect("missing gradient");
            debug_assert!(*gradient.components == *new_components);

            let mut movements = Vec::new();
            for (sample_i, grad_sample) in gradient.samples.to_cpu().iter().enumerate() {
                // translate from the old sample id in gradients to the new ones
                let mut grad_sample = grad_sample.to_vec();
                let old_sample_i = usize::try_from(grad_sample[0]).expect("could not convert to usize");

                let new_sample_i = samples_mapping[old_sample_i];
                grad_sample[0] = i32::try_from(new_sample_i).expect("could not convert to i32");

                let new_grad_sample_i = new_gradient_samples.position(&grad_sample).expect("missing entry in merged samples");

                movements.push(mts_data_movement_t {
                    sample_in: sample_i,
                    sample_out: new_grad_sample_i,
                    properties_start_in: 0,
                    properties_start_out: property_range.start,
                    properties_length: property_range.len(),
                });
            }

            new_gradient.move_data(&gradient.values, &movements)?;
        }

        let new_gradient = TensorBlock::new(
            new_gradient,
            new_gradient_samples,
            new_components,
            new_block.properties.clone()
        ).expect("created invalid gradient");

        new_block.add_gradient(parameter, new_gradient).expect("could not add gradient");
    }

    return Ok(new_block);
}
